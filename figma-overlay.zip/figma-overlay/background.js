// Injects content script into a tab if not already present, then sends a message
async function injectAndSend(tabId, msg) {
  try {
    // Try sending first — if content script is already there, this works immediately
    await chrome.tabs.sendMessage(tabId, msg);
  } catch (e) {
    // Content script not present — inject it, then send
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ['content.js']
      });
      // Small wait for script to initialize
      await new Promise(r => setTimeout(r, 100));
      await chrome.tabs.sendMessage(tabId, msg);
    } catch (err) {
      console.warn('Figma Overlay: could not inject/send', err);
    }
  }
}

// Listen for messages from the popup and forward to the active tab
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.target !== 'background') return;

  chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
    const tab = tabs[0];
    if (!tab?.id) return;
    await injectAndSend(tab.id, msg.payload);
    sendResponse({ ok: true });
  });

  return true; // keep channel open for async response
});
