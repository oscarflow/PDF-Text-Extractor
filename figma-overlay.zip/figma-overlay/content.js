(() => {
  if (window.__figmaOverlayInit) return;
  window.__figmaOverlayInit = true;

  /* ── BUILD OVERLAY DOM ── */
  const root = document.createElement('div');
  root.style.cssText = `
    all: initial;
    position: fixed !important;
    top: 0 !important;
    left: 0 !important;
    width: 0 !important;
    height: 0 !important;
    z-index: 2147483647 !important;
    pointer-events: none !important;
  `;

  const img = document.createElement('img');
  img.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    display: none;
    cursor: move;
    pointer-events: auto;
    user-select: none;
    -webkit-user-drag: none;
    z-index: 2147483646;
  `;

  const CORNERS = ['nw', 'ne', 'sw', 'se'];
  const handles = {};
  CORNERS.forEach(c => {
    const el = document.createElement('div');
    el.style.cssText = `
      position: fixed;
      width: 12px;
      height: 12px;
      background: #c8f135;
      border: 2px solid #000;
      border-radius: 2px;
      pointer-events: auto;
      display: none;
      z-index: 2147483647;
      cursor: ${(c === 'nw' || c === 'se') ? 'nwse-resize' : 'nesw-resize'};
    `;
    handles[c] = el;
    document.documentElement.appendChild(el);
  });

  document.documentElement.appendChild(img);
  document.documentElement.appendChild(root);

  /* ── STATE ── */
  let x = 0, y = 0, w = 0, h = 0, visible = false;

  function applyTransform() {
    img.style.left   = x + 'px';
    img.style.top    = y + 'px';
    img.style.width  = w + 'px';
    img.style.height = h + 'px';
    updateHandles();
  }

  function updateHandles() {
    const show = visible && img.style.display !== 'none';
    handles.nw.style.left = (x - 6) + 'px';  handles.nw.style.top = (y - 6) + 'px';
    handles.ne.style.left = (x + w - 6) + 'px'; handles.ne.style.top = (y - 6) + 'px';
    handles.sw.style.left = (x - 6) + 'px';  handles.sw.style.top = (y + h - 6) + 'px';
    handles.se.style.left = (x + w - 6) + 'px'; handles.se.style.top = (y + h - 6) + 'px';
    CORNERS.forEach(c => { handles[c].style.display = show ? 'block' : 'none'; });
  }

  /* ── DRAG ── */
  let dragging = false, dragStart = {};
  img.addEventListener('mousedown', e => {
    dragging = true;
    dragStart = { mx: e.clientX, my: e.clientY, ox: x, oy: y };
    e.preventDefault();
  });

  /* ── RESIZE ── */
  let resizing = false, resizeCorner = '', rs = {};
  CORNERS.forEach(c => {
    handles[c].addEventListener('mousedown', e => {
      resizing = true;
      resizeCorner = c;
      rs = { mx: e.clientX, my: e.clientY, x, y, w, h };
      e.preventDefault();
      e.stopPropagation();
    });
  });

  document.addEventListener('mousemove', e => {
    if (dragging) {
      x = dragStart.ox + (e.clientX - dragStart.mx);
      y = dragStart.oy + (e.clientY - dragStart.my);
      applyTransform();
      return;
    }
    if (!resizing) return;
    const dx = e.clientX - rs.mx, dy = e.clientY - rs.my;
    let nx = rs.x, ny = rs.y, nw = rs.w, nh = rs.h;
    if      (resizeCorner === 'se') { nw = Math.max(40, nw + dx); nh = Math.max(40, nh + dy); }
    else if (resizeCorner === 'sw') { nw = Math.max(40, nw - dx); nh = Math.max(40, nh + dy); nx = rs.x + (rs.w - nw); }
    else if (resizeCorner === 'ne') { nw = Math.max(40, nw + dx); nh = Math.max(40, nh - dy); ny = rs.y + (rs.h - nh); }
    else if (resizeCorner === 'nw') { nw = Math.max(40, nw - dx); nh = Math.max(40, nh - dy); nx = rs.x + (rs.w - nw); ny = rs.y + (rs.h - nh); }
    x = nx; y = ny; w = nw; h = nh;
    applyTransform();
  });

  document.addEventListener('mouseup', () => { dragging = false; resizing = false; });

  /* ── KEYBOARD NUDGE (Alt + arrows) ── */
  document.addEventListener('keydown', e => {
    if (!visible) return;
    if (!e.altKey) return;
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.isContentEditable) return;
    const step = e.shiftKey ? 10 : 1;
    if (e.key === 'ArrowLeft')  { x -= step; applyTransform(); e.preventDefault(); }
    if (e.key === 'ArrowRight') { x += step; applyTransform(); e.preventDefault(); }
    if (e.key === 'ArrowUp')    { y -= step; applyTransform(); e.preventDefault(); }
    if (e.key === 'ArrowDown')  { y += step; applyTransform(); e.preventDefault(); }
  });

  /* ── MESSAGES FROM BACKGROUND ── */
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'FO_SET') {
      img.src          = msg.dataUrl;
      w = msg.w; h = msg.h;
      x = 0; y = 0;
      img.style.opacity = msg.opacity;
      visible           = msg.visible;
      img.style.display = visible ? 'block' : 'none';
      applyTransform();
    }
    else if (msg.type === 'FO_TOGGLE') {
      visible = msg.visible;
      img.style.display = visible ? 'block' : 'none';
      updateHandles();
    }
    else if (msg.type === 'FO_OPACITY') {
      img.style.opacity = msg.opacity;
    }
    else if (msg.type === 'FO_CLEAR') {
      img.style.display = 'none';
      visible = false;
      updateHandles();
    }
  });

})();
