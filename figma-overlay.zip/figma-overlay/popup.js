let images = { desktop: null, mobile: null };
let currentBP = 'desktop';
let overlayOn = true;
let opacity = 50;

/* ── SEND TO CONTENT SCRIPT ── */
async function sendToTab(msg) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return;
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content.js']
    });
  } catch(e) {}
  try {
    await chrome.tabs.sendMessage(tab.id, msg);
  } catch(e) {}
}

/* ── IMAGE LOADING ── */
function loadImage(file, bp) {
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    const dataUrl = e.target.result;
    const img = new Image();
    img.onload = () => {
      images[bp] = { dataUrl, w: img.naturalWidth, h: img.naturalHeight };
      const dzId = bp === 'desktop' ? 'dzDesktop' : 'dzMobile';
      const dz = document.getElementById(dzId);
      dz.classList.add('loaded');
      document.getElementById(`dz${bp.charAt(0).toUpperCase()+bp.slice(1)}Label`).textContent =
        bp === 'desktop' ? '✓ Desktop loaded' : '✓ Mobile loaded';
      document.getElementById(`dz${bp.charAt(0).toUpperCase()+bp.slice(1)}Sub`).textContent =
        img.naturalWidth + ' × ' + img.naturalHeight + 'px';
      if (bp === currentBP) pushOverlay();
    };
    img.src = dataUrl;
  };
  reader.readAsDataURL(file);
}

/* ── DROP ZONES ── */
function dzOver(e, id) {
  e.preventDefault();
  document.getElementById(id).classList.add('over');
}
function dzLeave(id) {
  document.getElementById(id).classList.remove('over');
}
function dzDrop(e, bp) {
  e.preventDefault();
  const id = bp === 'desktop' ? 'dzDesktop' : 'dzMobile';
  document.getElementById(id).classList.remove('over');
  const file = e.dataTransfer.files[0];
  if (file && file.type.startsWith('image/')) loadImage(file, bp);
}

/* ── BREAKPOINT ── */
function setBreakpoint(bp) {
  currentBP = bp;
  document.getElementById('btnDesktop').classList.toggle('active', bp === 'desktop');
  document.getElementById('btnMobile').classList.toggle('active', bp === 'mobile');
  pushOverlay();
}

/* ── OPACITY ── */
function setOpacity(v) {
  opacity = parseInt(v);
  document.getElementById('opacityVal').textContent = v + '%';
  sendToTab({ type: 'FO_OPACITY', opacity: opacity / 100 });
}

/* ── TOGGLE ── */
function toggleOverlay() {
  overlayOn = !overlayOn;
  const btn = document.getElementById('btnToggle');
  btn.classList.toggle('on', overlayOn);
  btn.textContent = overlayOn ? 'OVERLAY ON' : 'OVERLAY OFF';
  sendToTab({ type: 'FO_TOGGLE', visible: overlayOn });
}

/* ── RESET POSITION ── */
function resetOverlay() {
  pushOverlay();
}

/* ── PUSH FULL OVERLAY STATE ── */
function pushOverlay() {
  const img = images[currentBP];
  const status = document.getElementById('status');
  if (!img) {
    status.textContent = 'No image loaded';
    status.className = 'status';
    sendToTab({ type: 'FO_CLEAR' });
    return;
  }
  status.textContent = currentBP.toUpperCase() + ' · ' + img.w + '×' + img.h;
  status.className = 'status active';
  sendToTab({
    type: 'FO_SET',
    dataUrl: img.dataUrl,
    w: img.w,
    h: img.h,
    opacity: opacity / 100,
    visible: overlayOn
  });
}
