(() => {
  /* Only inject once */
  if (window.__figmaOverlayInit) return;
  window.__figmaOverlayInit = true;

  /* ── CREATE OVERLAY ELEMENTS ── */
  const overlay = document.createElement('div');
  overlay.id = '__figma_overlay_root';
  overlay.style.cssText = `
    position: fixed;
    top: 0; left: 0;
    width: 0; height: 0;
    z-index: 2147483647;
    pointer-events: none;
  `;

  const img = document.createElement('img');
  img.id = '__figma_overlay_img';
  img.style.cssText = `
    position: absolute;
    top: 0; left: 0;
    display: none;
    cursor: move;
    pointer-events: auto;
    user-select: none;
    -webkit-user-drag: none;
  `;

  /* Corner handles */
  const corners = ['nw','ne','sw','se'];
  const handleEls = {};
  corners.forEach(c => {
    const h = document.createElement('div');
    h.dataset.corner = c;
    h.style.cssText = `
      position: absolute;
      width: 12px; height: 12px;
      background: #c8f135;
      border: 2px solid #000;
      border-radius: 2px;
      pointer-events: auto;
      display: none;
      z-index: 1;
      cursor: ${c === 'nw' || c === 'se' ? 'nwse-resize' : 'nesw-resize'};
    `;
    handleEls[c] = h;
    overlay.appendChild(h);
  });

  overlay.appendChild(img);
  document.documentElement.appendChild(overlay);

  /* ── STATE ── */
  let x = 0, y = 0, w = 0, h = 0;
  let visible = true;

  /* ── POSITION HELPERS ── */
  function applyTransform() {
    img.style.left = x + 'px';
    img.style.top  = y + 'px';
    img.style.width  = w + 'px';
    img.style.height = h + 'px';
    positionHandles();
  }

  function positionHandles() {
    const show = visible && img.style.display !== 'none';
    handleEls.nw.style.left = (x - 6) + 'px'; handleEls.nw.style.top = (y - 6) + 'px';
    handleEls.ne.style.left = (x + w - 6) + 'px'; handleEls.ne.style.top = (y - 6) + 'px';
    handleEls.sw.style.left = (x - 6) + 'px'; handleEls.sw.style.top = (y + h - 6) + 'px';
    handleEls.se.style.left = (x + w - 6) + 'px'; handleEls.se.style.top = (y + h - 6) + 'px';
    corners.forEach(c => { handleEls[c].style.display = show ? 'block' : 'none'; });
  }

  /* ── DRAG ── */
  let dragging = false, dragStart = {};
  img.addEventListener('mousedown', e => {
    dragging = true;
    dragStart = { mx: e.clientX, my: e.clientY, ox: x, oy: y };
    e.preventDefault();
  });

  /* ── RESIZE ── */
  let resizing = false, resizeCorner = '', resizeStart = {};
  corners.forEach(c => {
    handleEls[c].addEventListener('mousedown', e => {
      resizing = true;
      resizeCorner = c;
      resizeStart = { mx: e.clientX, my: e.clientY, x, y, w, h };
      e.preventDefault();
      e.stopPropagation();
    });
  });

  document.addEventListener('mousemove', e => {
    if (dragging) {
      x = resizeStart.x || dragStart.ox + (e.clientX - dragStart.mx);
      y = resizeStart.y || dragStart.oy + (e.clientY - dragStart.my);
      // recalc properly
      x = dragStart.ox + (e.clientX - dragStart.mx);
      y = dragStart.oy + (e.clientY - dragStart.my);
      applyTransform();
      return;
    }
    if (!resizing) return;
    const dx = e.clientX - resizeStart.mx;
    const dy = e.clientY - resizeStart.my;
    let nx = resizeStart.x, ny = resizeStart.y, nw = resizeStart.w, nh = resizeStart.h;
    if (resizeCorner === 'se') { nw = Math.max(40, nw + dx); nh = Math.max(40, nh + dy); }
    else if (resizeCorner === 'sw') { nw = Math.max(40, nw - dx); nh = Math.max(40, nh + dy); nx = resizeStart.x + (resizeStart.w - nw); }
    else if (resizeCorner === 'ne') { nw = Math.max(40, nw + dx); nh = Math.max(40, nh - dy); ny = resizeStart.y + (resizeStart.h - nh); }
    else if (resizeCorner === 'nw') { nw = Math.max(40, nw - dx); nh = Math.max(40, nh - dy); nx = resizeStart.x + (resizeStart.w - nw); ny = resizeStart.y + (resizeStart.h - nh); }
    x = nx; y = ny; w = nw; h = nh;
    applyTransform();
  });

  document.addEventListener('mouseup', () => { dragging = false; resizing = false; });

  /* ── KEYBOARD NUDGE ── */
  document.addEventListener('keydown', e => {
    if (!visible || img.style.display === 'none') return;
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.isContentEditable) return;
    if (!e.altKey) return; // require Alt key to avoid interfering with page
    const step = e.shiftKey ? 10 : 1;
    if (e.key === 'ArrowLeft')  { x -= step; applyTransform(); e.preventDefault(); }
    if (e.key === 'ArrowRight') { x += step; applyTransform(); e.preventDefault(); }
    if (e.key === 'ArrowUp')    { y -= step; applyTransform(); e.preventDefault(); }
    if (e.key === 'ArrowDown')  { y += step; applyTransform(); e.preventDefault(); }
  });

  /* ── MESSAGE HANDLER ── */
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'FO_SET') {
      img.src = msg.dataUrl;
      w = msg.w;
      h = msg.h;
      x = 0; y = 0;
      img.style.opacity = msg.opacity;
      visible = msg.visible;
      img.style.display = visible ? 'block' : 'none';
      applyTransform();
    }
    else if (msg.type === 'FO_TOGGLE') {
      visible = msg.visible;
      img.style.display = visible ? 'block' : 'none';
      positionHandles();
    }
    else if (msg.type === 'FO_OPACITY') {
      img.style.opacity = msg.opacity;
    }
    else if (msg.type === 'FO_CLEAR') {
      img.style.display = 'none';
      positionHandles();
    }
  });

})();
