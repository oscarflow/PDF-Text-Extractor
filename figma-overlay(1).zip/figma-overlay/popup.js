/* ── STATE ── */
const images = { desktop: null, mobile: null };
let currentBP = 'desktop';
let overlayOn = true;
let opacity = 50;

/* ── DOM REFS ── */
const dzDesktop      = document.getElementById('dzDesktop');
const dzMobile       = document.getElementById('dzMobile');
const fileDesktop    = document.getElementById('fileDesktop');
const fileMobile     = document.getElementById('fileMobile');
const btnDesktop     = document.getElementById('btnDesktop');
const btnMobile      = document.getElementById('btnMobile');
const btnToggle      = document.getElementById('btnToggle');
const btnReset       = document.getElementById('btnReset');
const opacitySlider  = document.getElementById('opacitySlider');
const opacityVal     = document.getElementById('opacityVal');
const statusEl       = document.getElementById('status');

/* ── SEND MESSAGE TO ACTIVE TAB ── */
async function sendToTab(msg) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return;
  // Ensure content script is injected
  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
  } catch(e) { /* already injected */ }
  try {
    await chrome.tabs.sendMessage(tab.id, msg);
  } catch(e) { console.warn('sendMessage failed:', e); }
}

/* ── LOAD IMAGE FROM FILE ── */
function loadImage(file, bp) {
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    const dataUrl = e.target.result;
    const imgEl = new Image();
    imgEl.onload = () => {
      images[bp] = { dataUrl, w: imgEl.naturalWidth, h: imgEl.naturalHeight };
      const dz    = bp === 'desktop' ? dzDesktop : dzMobile;
      const label = document.getElementById(`dz${cap(bp)}Label`);
      const sub   = document.getElementById(`dz${cap(bp)}Sub`);
      dz.classList.add('loaded');
      label.textContent = `✓ ${cap(bp)} loaded`;
      sub.textContent   = `${imgEl.naturalWidth} × ${imgEl.naturalHeight}px`;
      if (bp === currentBP) pushOverlay();
    };
    imgEl.src = dataUrl;
  };
  reader.readAsDataURL(file);
}

function cap(s) { return s.charAt(0).toUpperCase() + s.slice(1); }

/* ── DROP ZONE EVENTS ── */
[dzDesktop, dzMobile].forEach(dz => {
  const bp = dz.id === 'dzDesktop' ? 'desktop' : 'mobile';
  const fileInput = bp === 'desktop' ? fileDesktop : fileMobile;

  dz.addEventListener('click', () => fileInput.click());

  dz.addEventListener('dragover', e => {
    e.preventDefault();
    dz.classList.add('over');
  });
  dz.addEventListener('dragleave', () => dz.classList.remove('over'));
  dz.addEventListener('drop', e => {
    e.preventDefault();
    dz.classList.remove('over');
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) loadImage(file, bp);
  });
});

fileDesktop.addEventListener('change', e => loadImage(e.target.files[0], 'desktop'));
fileMobile.addEventListener('change',  e => loadImage(e.target.files[0], 'mobile'));

/* ── BREAKPOINT ── */
btnDesktop.addEventListener('click', () => setBreakpoint('desktop'));
btnMobile.addEventListener('click',  () => setBreakpoint('mobile'));

function setBreakpoint(bp) {
  currentBP = bp;
  btnDesktop.classList.toggle('active', bp === 'desktop');
  btnMobile.classList.toggle('active',  bp === 'mobile');
  pushOverlay();
}

/* ── OPACITY ── */
opacitySlider.addEventListener('input', () => {
  opacity = parseInt(opacitySlider.value);
  opacityVal.textContent = opacity + '%';
  sendToTab({ type: 'FO_OPACITY', opacity: opacity / 100 });
});

/* ── TOGGLE ── */
btnToggle.addEventListener('click', () => {
  overlayOn = !overlayOn;
  btnToggle.classList.toggle('on', overlayOn);
  btnToggle.textContent = overlayOn ? 'OVERLAY ON' : 'OVERLAY OFF';
  sendToTab({ type: 'FO_TOGGLE', visible: overlayOn });
});

/* ── RESET ── */
btnReset.addEventListener('click', () => pushOverlay());

/* ── PUSH FULL STATE TO TAB ── */
function pushOverlay() {
  const img = images[currentBP];
  if (!img) {
    statusEl.textContent = 'No image loaded';
    statusEl.className = 'status';
    sendToTab({ type: 'FO_CLEAR' });
    return;
  }
  statusEl.textContent = currentBP.toUpperCase() + ' · ' + img.w + '×' + img.h;
  statusEl.className = 'status active';
  sendToTab({
    type: 'FO_SET',
    dataUrl: img.dataUrl,
    w: img.w,
    h: img.h,
    opacity: opacity / 100,
    visible: overlayOn
  });
}
