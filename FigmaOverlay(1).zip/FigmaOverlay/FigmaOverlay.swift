import Cocoa

// ── APP ENTRY ──────────────────────────────────────────────────────────────
final class AppDelegate: NSObject, NSApplicationDelegate {
    var overlayWin: OverlayWindow!
    var controlWin: ControlPanel!

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory)
        overlayWin = OverlayWindow()
        overlayWin.makeKeyAndOrderFront(nil)
        controlWin = ControlPanel(overlayWindow: overlayWin)
        controlWin.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ app: NSApplication) -> Bool { true }
}

// ── OVERLAY WINDOW ─────────────────────────────────────────────────────────
final class OverlayWindow: NSWindow {
    let imageView = NSImageView()

    init() {
        let screen = NSScreen.main?.frame ?? NSRect(x: 0, y: 0, width: 1440, height: 900)
        let f = NSRect(x: screen.midX - 300, y: screen.midY - 400, width: 600, height: 800)
        super.init(contentRect: f, styleMask: [.borderless, .resizable], backing: .buffered, defer: false)

        backgroundColor    = .clear
        isOpaque           = false
        hasShadow          = false
        level              = .floating
        collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary]

        imageView.frame            = contentView!.bounds
        imageView.autoresizingMask = [.width, .height]
        imageView.imageScaling     = .scaleAxesIndependently
        imageView.imageAlignment   = .alignTopLeft
        imageView.wantsLayer       = true
        imageView.layer?.opacity   = 0.5

        let dragView = DragAndDropView(frame: contentView!.bounds, overlayWindow: self)
        dragView.autoresizingMask = [.width, .height]
        contentView!.addSubview(dragView)
        contentView!.addSubview(imageView)

        showPlaceholder()
    }

    func showPlaceholder() {
        let size = NSSize(width: 600, height: 800)
        let img  = NSImage(size: size)
        img.lockFocus()
        NSColor(white: 0.15, alpha: 0.85).setFill()
        NSBezierPath(rect: NSRect(origin: .zero, size: size)).fill()
        let attrs: [NSAttributedString.Key: Any] = [
            .foregroundColor: NSColor(red: 0.78, green: 0.95, blue: 0.2, alpha: 0.9),
            .font: NSFont.monospacedSystemFont(ofSize: 15, weight: .medium)
        ]
        let s  = NSAttributedString(string: "Drop Figma PNG here", attributes: attrs)
        let sz = s.size()
        s.draw(at: NSPoint(x: (size.width - sz.width) / 2, y: (size.height - sz.height) / 2))
        img.unlockFocus()
        imageView.image = img
    }

    func loadImage(_ image: NSImage) {
        imageView.image = image
        let ratio = image.size.height / image.size.width
        let newH  = frame.width * ratio
        setContentSize(NSSize(width: frame.width, height: newH))
    }

    func setOpacity(_ v: Float) { imageView.layer?.opacity = v }

    override var canBecomeKey: Bool  { true }
    override var canBecomeMain: Bool { true }
}

// ── DRAG & DROP + MOVE VIEW ────────────────────────────────────────────────
final class DragAndDropView: NSView {
    weak var overlayWindow: OverlayWindow?
    private var dragStart: NSPoint = .zero

    init(frame: NSRect, overlayWindow: OverlayWindow) {
        self.overlayWindow = overlayWindow
        super.init(frame: frame)
        registerForDraggedTypes([.fileURL])
    }
    required init?(coder: NSCoder) { fatalError() }

    override func draggingEntered(_ sender: NSDraggingInfo) -> NSDragOperation { .copy }
    override func performDragOperation(_ sender: NSDraggingInfo) -> Bool {
        guard
            let urls  = sender.draggingPasteboard.readObjects(forClasses: [NSURL.self]) as? [URL],
            let url   = urls.first,
            let image = NSImage(contentsOf: url)
        else { return false }
        overlayWindow?.loadImage(image)
        return true
    }

    override func mouseDown(with event: NSEvent) {
        dragStart = event.locationInWindow
    }

    override func mouseDragged(with event: NSEvent) {
        guard let win = overlayWindow else { return }
        let current = event.locationInWindow
        let dx = current.x - dragStart.x
        let dy = current.y - dragStart.y
        var origin = win.frame.origin
        origin.x += dx
        origin.y += dy
        win.setFrameOrigin(origin)
    }
}

// ── CONTROL PANEL ──────────────────────────────────────────────────────────
final class ControlPanel: NSPanel {
    weak var overlayWindow: OverlayWindow?
    private var opValLabel: NSTextField!

    // Colors
    private let bg     = NSColor(red: 0.09, green: 0.09, blue: 0.10, alpha: 1)
    private let accent = NSColor(red: 0.78, green: 0.95, blue: 0.20, alpha: 1)
    private let dim    = NSColor(white: 0.55, alpha: 1)
    private let faint  = NSColor(white: 0.38, alpha: 1)
    private let red    = NSColor(red: 1.0,  green: 0.30, blue: 0.30, alpha: 1)

    init(overlayWindow: OverlayWindow) {
        self.overlayWindow = overlayWindow
        let f = NSRect(x: 0, y: 0, width: 300, height: 240)
        super.init(contentRect: f, styleMask: [.titled, .closable, .nonactivatingPanel], backing: .buffered, defer: false)

        title              = "Figma Overlay"
        level              = .floating
        collectionBehavior = [.canJoinAllSpaces]
        isMovableByWindowBackground = true

        if let screen = NSScreen.main {
            let sx = screen.visibleFrame
            setFrameOrigin(NSPoint(x: sx.maxX - f.width - 20, y: sx.minY + 20))
        }

        buildUI()
    }

    private func buildUI() {
        guard let v = contentView else { return }
        v.wantsLayer = true
        v.layer?.backgroundColor = bg.cgColor

        // ── OPACITY label + value ──
        let opLabel = makeLabel("OPACITY", color: dim)
        opLabel.frame = NSRect(x: 20, y: 196, width: 160, height: 16)
        v.addSubview(opLabel)

        opValLabel = makeLabel("50%", color: accent)
        opValLabel.frame = NSRect(x: 240, y: 196, width: 44, height: 16)
        opValLabel.alignment = .right
        v.addSubview(opValLabel)

        // ── Opacity slider ──
        let slider = NSSlider(value: 0.5, minValue: 0, maxValue: 1, target: self, action: #selector(opacityChanged(_:)))
        slider.frame = NSRect(x: 20, y: 172, width: 264, height: 20)
        v.addSubview(slider)

        // ── Toggle button ──
        let toggle = makeButton("OVERLAY ON", color: accent, action: #selector(toggleOverlay(_:)))
        toggle.frame = NSRect(x: 20, y: 130, width: 264, height: 34)
        toggle.setButtonType(.pushOnPushOff)
        toggle.state = .on
        v.addSubview(toggle)

        // ── Load PNG button ──
        let loadBtn = makeButton("Load PNG…", color: accent, action: #selector(openFile(_:)))
        loadBtn.frame = NSRect(x: 20, y: 86, width: 264, height: 34)
        v.addSubview(loadBtn)

        // ── Close / Quit button ──
        let closeBtn = makeButton("Quit", color: red, action: #selector(quitApp(_:)))
        closeBtn.frame = NSRect(x: 20, y: 44, width: 264, height: 34)
        v.addSubview(closeBtn)

        // ── Hints ──
        let hint1 = makeLabel("Drag overlay window to reposition it", color: faint)
        hint1.frame = NSRect(x: 20, y: 24, width: 264, height: 14)
        v.addSubview(hint1)

        let hint2 = makeLabel("Option+arrows to nudge  ·  Shift+Option = 10px", color: faint)
        hint2.frame = NSRect(x: 20, y: 8, width: 264, height: 14)
        v.addSubview(hint2)
    }

    private func makeLabel(_ text: String, color: NSColor) -> NSTextField {
        let f = NSTextField(labelWithString: text)
        f.font            = .monospacedSystemFont(ofSize: 10, weight: .regular)
        f.textColor       = color
        f.isBordered      = false
        f.drawsBackground = false
        return f
    }

    private func makeButton(_ title: String, color: NSColor, action: Selector) -> NSButton {
        let b = NSButton(title: title, target: self, action: action)
        b.bezelStyle       = .rounded
        b.font             = .monospacedSystemFont(ofSize: 11, weight: .semibold)
        b.wantsLayer       = true
        b.appearance       = NSAppearance(named: .aqua)
        b.contentTintColor = bg
        b.layer?.backgroundColor = color.cgColor
        b.layer?.cornerRadius    = 5
        return b
    }

    @objc private func opacityChanged(_ sender: NSSlider) {
        let v = Float(sender.floatValue)
        overlayWindow?.setOpacity(v)
        opValLabel.stringValue = "\(Int(v * 100))%"
    }

    @objc private func toggleOverlay(_ sender: NSButton) {
        let on = sender.state == .on
        sender.title = on ? "OVERLAY ON" : "OVERLAY OFF"
        overlayWindow?.alphaValue = on ? 1 : 0
    }

    @objc private func openFile(_ sender: Any) {
        let panel = NSOpenPanel()
        panel.allowedContentTypes     = [.png, .jpeg, .tiff]
        panel.allowsMultipleSelection = false
        panel.begin { [weak self] resp in
            guard resp == .OK, let url = panel.url, let img = NSImage(contentsOf: url) else { return }
            self?.overlayWindow?.loadImage(img)
        }
    }

    @objc private func quitApp(_ sender: Any) {
        overlayWindow?.close(); NSApp.terminate(nil)
    }
}

// ── MAIN ───────────────────────────────────────────────────────────────────
let app      = NSApplication.shared
let delegate = AppDelegate()
app.delegate = delegate
app.run()
