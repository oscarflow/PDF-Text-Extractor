import Cocoa

// ── APP ENTRY ──────────────────────────────────────────────────────────────
final class AppDelegate: NSObject, NSApplicationDelegate {
    var window: OverlayWindow!
    var panel: ControlPanel!

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory) // no Dock icon while running

        window = OverlayWindow()
        window.makeKeyAndOrderFront(nil)

        panel = ControlPanel(overlayWindow: window)
        panel.makeKeyAndOrderFront(nil)

        NSApp.activate(ignoringOtherApps: true)
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ app: NSApplication) -> Bool { true }
}

// ── OVERLAY WINDOW ─────────────────────────────────────────────────────────
final class OverlayWindow: NSWindow {
    private let imageView = NSImageView()

    init() {
        let screen = NSScreen.main?.frame ?? NSRect(x: 0, y: 0, width: 800, height: 600)
        let frame  = NSRect(x: screen.midX - 300, y: screen.midY - 400, width: 600, height: 800)

        super.init(
            contentRect: frame,
            styleMask:   [.borderless, .resizable],
            backing:     .buffered,
            defer:       false
        )

        backgroundColor         = .clear
        isOpaque                = false
        hasShadow               = false
        level                   = .floating
        collectionBehavior      = [.canJoinAllSpaces, .fullScreenAuxiliary]
        isMovableByWindowBackground = true

        imageView.frame               = contentView!.bounds
        imageView.autoresizingMask    = [.width, .height]
        imageView.imageScaling        = .scaleAxesIndependently
        imageView.imageAlignment      = .alignTopLeft
        imageView.wantsLayer          = true
        imageView.layer?.opacity      = 0.5

        // Drop support
        imageView.registerForDraggedTypes([.fileURL, .tiff, .png])

        let dropDelegate = DropView(frame: contentView!.bounds, overlayWindow: self)
        dropDelegate.autoresizingMask = [.width, .height]
        contentView!.addSubview(dropDelegate)
        contentView!.addSubview(imageView)

        // Placeholder
        showPlaceholder()
    }

    func showPlaceholder() {
        let placeholder = NSImage(size: NSSize(width: 600, height: 800))
        placeholder.lockFocus()
        NSColor(white: 0.2, alpha: 0.6).setFill()
        NSBezierPath(rect: NSRect(x: 0, y: 0, width: 600, height: 800)).fill()

        let attrs: [NSAttributedString.Key: Any] = [
            .foregroundColor: NSColor(red: 0.78, green: 0.95, blue: 0.2, alpha: 0.8),
            .font: NSFont.monospacedSystemFont(ofSize: 14, weight: .medium)
        ]
        let str = NSAttributedString(string: "Drop Figma PNG here", attributes: attrs)
        let strSize = str.size()
        str.draw(at: NSPoint(x: (600 - strSize.width) / 2, y: (800 - strSize.height) / 2))
        placeholder.unlockFocus()
        imageView.image = placeholder
    }

    func loadImage(_ image: NSImage) {
        imageView.image = image
        // Resize window to match image aspect ratio, keeping current width
        let ratio  = image.size.height / image.size.width
        let newH   = frame.width * ratio
        setContentSize(NSSize(width: frame.width, height: newH))
    }

    func setOpacity(_ value: Float) {
        imageView.layer?.opacity = value
    }

    override var canBecomeKey: Bool { true }
    override var canBecomeMain: Bool { true }
}

// ── DROP VIEW ──────────────────────────────────────────────────────────────
final class DropView: NSView {
    weak var overlayWindow: OverlayWindow?

    init(frame: NSRect, overlayWindow: OverlayWindow) {
        self.overlayWindow = overlayWindow
        super.init(frame: frame)
        registerForDraggedTypes([.fileURL])
    }
    required init?(coder: NSCoder) { fatalError() }

    override func draggingEntered(_ sender: NSDraggingInfo) -> NSDragOperation {
        return .copy
    }

    override func performDragOperation(_ sender: NSDraggingInfo) -> Bool {
        guard
            let urls  = sender.draggingPasteboard.readObjects(forClasses: [NSURL.self]) as? [URL],
            let url   = urls.first,
            let image = NSImage(contentsOf: url)
        else { return false }
        overlayWindow?.loadImage(image)
        return true
    }
}

// ── CONTROL PANEL ──────────────────────────────────────────────────────────
final class ControlPanel: NSPanel {
    weak var overlayWindow: OverlayWindow?

    init(overlayWindow: OverlayWindow) {
        self.overlayWindow = overlayWindow

        let frame = NSRect(x: 0, y: 0, width: 280, height: 200)
        super.init(
            contentRect: frame,
            styleMask:   [.titled, .closable, .nonactivatingPanel],
            backing:     .buffered,
            defer:       false
        )

        title                   = "Figma Overlay"
        level                   = .floating
        isMovableByWindowBackground = true
        collectionBehavior      = [.canJoinAllSpaces]

        // Position panel bottom-right of screen
        if let screen = NSScreen.main {
            let sx = screen.visibleFrame
            setFrameOrigin(NSPoint(x: sx.maxX - frame.width - 20, y: sx.minY + 20))
        }

        buildUI()
    }

    private func buildUI() {
        let v = contentView!
        v.wantsLayer = true
        v.layer?.backgroundColor = NSColor(white: 0.1, alpha: 1).cgColor

        // ── Opacity label
        let opLabel = label("OPACITY", x: 20, y: 150)
        v.addSubview(opLabel)

        // ── Opacity value
        let opVal = NSTextField(labelWithString: "50%")
        opVal.frame = NSRect(x: 220, y: 148, width: 40, height: 18)
        opVal.font = .monospacedSystemFont(ofSize: 11, weight: .regular)
        opVal.textColor = NSColor(red: 0.78, green: 0.95, blue: 0.2, alpha: 1)
        opVal.identifier = NSUserInterfaceItemIdentifier("opVal")
        v.addSubview(opVal)

        // ── Opacity slider
        let slider = NSSlider(value: 0.5, minValue: 0, maxValue: 1, target: self, action: #selector(opacityChanged(_:)))
        slider.frame = NSRect(x: 20, y: 124, width: 240, height: 20)
        slider.identifier = NSUserInterfaceItemIdentifier("opSlider")
        v.addSubview(slider)

        // ── Toggle button
        let toggle = NSButton(title: "OVERLAY ON", target: self, action: #selector(toggleOverlay(_:)))
        toggle.frame = NSRect(x: 20, y: 84, width: 240, height: 32)
        toggle.bezelStyle = .rounded
        toggle.setButtonType(.pushOnPushOff)
        toggle.state = .on
        toggle.font = .monospacedSystemFont(ofSize: 11, weight: .medium)
        toggle.identifier = NSUserInterfaceItemIdentifier("toggleBtn")
        v.addSubview(toggle)

        // ── Load button
        let loadBtn = NSButton(title: "Load PNG…", target: self, action: #selector(openFile(_:)))
        loadBtn.frame = NSRect(x: 20, y: 44, width: 240, height: 32)
        loadBtn.bezelStyle = .rounded
        loadBtn.font = .monospacedSystemFont(ofSize: 11, weight: .medium)
        v.addSubview(loadBtn)

        // ── Hint
        let hint = label("drag PNG onto overlay · alt+arrows to nudge", x: 20, y: 16)
        hint.textColor = NSColor(white: 0.4, alpha: 1)
        v.addSubview(hint)
    }

    private func label(_ text: String, x: CGFloat, y: CGFloat) -> NSTextField {
        let f = NSTextField(labelWithString: text)
        f.frame = NSRect(x: x, y: y, width: 240, height: 16)
        f.font = .monospacedSystemFont(ofSize: 10, weight: .regular)
        f.textColor = NSColor(white: 0.5, alpha: 1)
        return f
    }

    @objc private func opacityChanged(_ sender: NSSlider) {
        let v = Float(sender.floatValue)
        overlayWindow?.setOpacity(v)
        if let lbl = contentView?.viewWithTag(0) as? NSTextField { lbl.stringValue = "\(Int(v * 100))%" }
        // find by identifier
        contentView?.subviews.forEach {
            if let tf = $0 as? NSTextField, tf.identifier?.rawValue == "opVal" {
                tf.stringValue = "\(Int(v * 100))%"
            }
        }
    }

    @objc private func toggleOverlay(_ sender: NSButton) {
        let on = sender.state == .on
        sender.title = on ? "OVERLAY ON" : "OVERLAY OFF"
        overlayWindow?.alphaValue = on ? 1 : 0
    }

    @objc private func openFile(_ sender: Any) {
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [.png, .jpeg, .tiff]
        panel.allowsMultipleSelection = false
        panel.begin { [weak self] response in
            guard response == .OK, let url = panel.url, let image = NSImage(contentsOf: url) else { return }
            self?.overlayWindow?.loadImage(image)
        }
    }
}

// ── MAIN ───────────────────────────────────────────────────────────────────
let app = NSApplication.shared
let delegate = AppDelegate()
app.delegate = delegate
app.run()
