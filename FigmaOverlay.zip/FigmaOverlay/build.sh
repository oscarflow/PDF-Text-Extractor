#!/bin/bash
set -e

echo "Building FigmaOverlay.app..."

# Compile
swiftc FigmaOverlay.swift -o FigmaOverlay \
  -framework Cocoa \
  -framework UniformTypeIdentifiers

# Create .app bundle structure
APP="FigmaOverlay.app"
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS"
mkdir -p "$APP/Contents/Resources"

# Move binary
mv FigmaOverlay "$APP/Contents/MacOS/FigmaOverlay"

# Write Info.plist
cat > "$APP/Contents/Info.plist" << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleExecutable</key>
  <string>FigmaOverlay</string>
  <key>CFBundleIdentifier</key>
  <string>com.local.figmaoverlay</string>
  <key>CFBundleName</key>
  <string>FigmaOverlay</string>
  <key>CFBundleVersion</key>
  <string>1.0</string>
  <key>NSHighResolutionCapable</key>
  <true/>
  <key>LSUIElement</key>
  <true/>
</dict>
</plist>
EOF

echo ""
echo "✓ Built FigmaOverlay.app"
echo ""
echo "To run:  open FigmaOverlay.app"
echo "To move to Applications:  mv FigmaOverlay.app /Applications/"
