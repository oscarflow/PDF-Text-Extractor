# FigmaOverlay

A transparent floating window for Mac that sits over any browser tab — including about:blank — so you can ghost your Figma export over your live email render.

---

## One-time setup (2 minutes)

1. Unzip the folder
2. Open Terminal
3. Run:

```
cd ~/Downloads/FigmaOverlay
chmod +x build.sh
./build.sh
open FigmaOverlay.app
```

That's it. The app is built and running.

**Optional — keep it in Applications:**
```
mv FigmaOverlay.app /Applications/
```

---

## Daily use

1. Open **FigmaOverlay.app**
2. Export your Figma artboard as PNG (1x)
3. **Drag the PNG** onto the transparent overlay window, or click **Load PNG…** in the control panel
4. Move the overlay window over your about:blank preview tab
5. Resize from any corner to line up with the render
6. Use the **opacity slider** to tune transparency

---

## Controls

| Action | How |
|---|---|
| Move overlay | Drag anywhere on the window |
| Resize | Drag any corner |
| Opacity | Slider in control panel |
| Toggle on/off | Button in control panel |
| Load new image | Drag onto window, or Load PNG… button |

---

## Notes

- The overlay window has no titlebar — it's just the image
- The control panel floats separately in the corner
- Both windows stay on top of everything, including other apps
- Works on any monitor, any tab, including about:blank
